<?php
include_once "koneksi.php";

if (isset($_GET['kategori'])) {
    $kategori = $_GET['kategori'];

    echo "<h3>Produk Kategori: $kategori</h3>";
    echo "<button onclick=\"tampilkanFormTambahProduk('$kategori')\">Tambah Produk</button>";
    echo "<table border='1' style='width:100%; margin-top:10px;'>
            <thead>
                <tr>
                    <th>Kode Barang</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Kategori</th>
                    <th>Gambar</th>
                </tr>
            </thead>
            <tbody>";

    $query = "SELECT * FROM produk WHERE kategori = '$kategori'";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>{$row['kode_barang']}</td>
                <td>{$row['nama_produk']}</td>
                <td>{$row['harga']}</td>
                <td>{$row['stok']}</td>
                <td>{$row['kategori']}</td>
                <td><img src='uploads/{$row['gambar']}' alt='{$row['nama_produk']}' width='50'></td>
            </tr>";
    }

    echo "</tbody></table>";
}
?>
