<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}


// Mengecek apakah keranjang belanja ada
if (!isset($_SESSION['keranjang']) || empty($_SESSION['keranjang'])) {
    echo "<script>alert('Keranjang belanja kosong!'); window.location = 'keranjang.php';</script>";
    exit;
}

// Inisialisasi variabel total
$total = 0;
$pembelian_data = []; // Menyimpan data untuk struk

foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    $query = mysqli_query($conn, "SELECT * FROM produk WHERE id_produk = '$id_produk'");
    $produk = mysqli_fetch_assoc($query);

    if (!$produk) {
        echo "<script>alert('Produk tidak ditemukan!'); window.location = 'keranjang.php';</script>";
        exit;
    }
$subtotal = intval($produk['harga']) * intval($produk['jumlah']);
$total += $subtotal;


    // Simpan data pembelian ke database
    $id_user = $_SESSION['user']['id_pelanggan'];
    $tanggal = date('Y-m-d H:i:s');
    mysqli_query($conn, "INSERT INTO pembelian (id_user, id_produk, jumlah, total_harga, tanggal)
                            VALUES ('$id_user', '$id_produk', '$jumlah', '$subtotal', '$tanggal')");

    // Tambahkan data ke array pembelian untuk struk
    $pembelian_data[] = [
        'nama_produk' => $produk['nama_produk'],
        'harga' => $produk['harga'],
        'jumlah' => $jumlah,
        'subtotal' => $subtotal
    ];

    // Mengurangi stok dari produk yang dibeli
    $new_stok = $produk['stok'] - $jumlah; // Mengurangi stok
    if ($new_stok >= 0) {
        // Update stok produk setelah pembelian
        $update_stok = mysqli_query($conn, "UPDATE produk SET stok = '$new_stok' WHERE id_produk = '$id_produk'");

        if (!$update_stok) {
            echo "<script>alert('Gagal mengupdate stok untuk produk: " . $produk['nama_produk'] . "');</script>";
            exit;
        }

        // Menambahkan transaksi keluar ke stok_keluar
        $keterangan = "Produk terjual melalui checkout.";
        $stok_keluar = mysqli_query($conn, "INSERT INTO stok_keluar (nama_produk, terjual, tanggal, keterangan)
                                               VALUES ('{$produk['nama_produk']}', '$jumlah', '$tanggal', '$keterangan')");

        if (!$stok_keluar) {
            echo "<script>alert('Gagal memasukkan data ke stok keluar: " . mysqli_error($conn) . "');</script>";
            exit;
        }
    } else {
        // Jika stok tidak cukup
        echo "<script>alert('Stok tidak cukup untuk produk: " . $produk['nama_produk'] . "'); window.location = 'keranjang.php';</script>";
        exit;
    }
}

// Kosongkan keranjang setelah checkout
unset($_SESSION['keranjang']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Pembayaran</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Struk Pembayaran</h1>
        <hr>
        <p><strong>Tanggal:</strong> <?= date('d-m-Y H:i:s') ?></p>
        <p><strong>Nama Pembeli:</strong> <?= $_SESSION['user']['nama'] ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pembelian_data as $item): ?>
                <tr>
                    <td><?= $item['nama_produk'] ?></td>
                    <td>Rp<?= number_format($item['harga']) ?></td>
                    <td><?= $item['jumlah'] ?></td>
                    <td>Rp<?= number_format($item['subtotal']) ?></td>
                </tr>
                <?php endforeach; ?>
                <tr>
                    <td colspan="3"><strong>Total</strong></td>
                    <td><strong>Rp<?= number_format($total) ?></strong></td>
                </tr>
            </tbody>
        </table>
        <hr>
        <p><strong>Terima kasih telah berbelanja!</strong></p>
        <a href="index.php" class="btn btn-primary">Kembali ke Beranda</a>
        <br><br>
        <!-- Tombol Print -->
        <button onclick="window.print();">Cetak Struk</button>
    </div>
</body>
</html>
