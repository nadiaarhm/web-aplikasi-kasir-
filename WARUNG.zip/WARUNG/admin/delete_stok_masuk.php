<?php
include_once "koneksi.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    // Query untuk menghapus data pelanggan berdasarkan ID
    $query = mysqli_query($koneksi, "DELETE FROM stok_masuk WHERE id_stok = $id_stok");
    $_SESSION['notif'] = "Data berhasil dihapus!";
    header('location:stok_masuk.php');
}
?>
