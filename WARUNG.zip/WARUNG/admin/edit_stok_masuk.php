<?php
include_once "koneksi.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = mysqli_query($koneksi, "SELECT * FROM stok_masuk WHERE id_stok = '$id'");
    $data = mysqli_fetch_array($query);
}

if (isset($_POST['update'])) {
    $tanggal = $_POST['tanggal'];
    $kode_barang = $_POST['kode_barang'];
    $stok = $_POST['stok'];
    $keterangan = $_POST['keterangan'];

    mysqli_query($koneksi, "UPDATE stok_masuk SET tanggal='$tanggal', kode_barang='$kode_barang', stok='$stok', keterangan='$keterangan' WHERE id='$id'");
    $_SESSION['notif'] = "Data berhasil diupdate!";
    header('location:stok_masuk.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Stok Masuk</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 8px;
            font-size: 14px;
            color: #333;
        }
        input[type="date"],
        input[type="text"],
        input[type="number"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }
        button[type="submit"] {
            padding: 10px;
            background-color: #4CAF50;
            border: none;
            color: white;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Stok Masuk</h2>
        <form method="POST">
            <label for="tanggal">Tanggal</label>
            <input type="date" name="tanggal" value="<?php echo $data['tanggal']; ?>" required>
            
            <label for="kode_barang">Kode Barang</label>
            <input type="text" name="kode_barang" value="<?php echo $data['kode_barang']; ?>" required>
            
            <label for="stok">Jumlah</label>
            <input type="number" name="stok" value="<?php echo $data['stok']; ?>" required>
            
            <label for="keterangan">Keterangan</label>
            <input type="text" name="keterangan" value="<?php echo $data['keterangan']; ?>" required>
            
            <button type="submit" name="update">Update</button>
        </form>
    </div>
</body>
</html>
