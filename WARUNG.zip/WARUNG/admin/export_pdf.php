<?php
require('fpdf/fpdf.php');

// Koneksi database
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
$sql = "
    SELECT t.tanggal_transaksi, t.total_harga, p.nama_pelanggan
    FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
";
$result = $conn->query($sql);

// Inisialisasi PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Laporan Transaksi', 0, 1, 'C');

// Header tabel
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 10, 'No', 1);
$pdf->Cell(50, 10, 'Tanggal', 1);
$pdf->Cell(80, 10, 'Nama Pelanggan', 1);
$pdf->Cell(50, 10, 'Total Harga', 1);
$pdf->Ln();

$no = 1;
$pdf->SetFont('Arial', '', 10);
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(10, 10, $no++, 1);
    $pdf->Cell(50, 10, $row['tanggal_transaksi'], 1);
    $pdf->Cell(80, 10, $row['nama_pelanggan'], 1);
    $pdf->Cell(50, 10, 'Rp ' . number_format($row['total_harga'], 0, ',', '.'), 1);
    $pdf->Ln();
}

$pdf->Output();
?>
