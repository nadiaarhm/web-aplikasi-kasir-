<?php
$conn = mysqli_connect("localhost", "root", "", "kasir");

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>kasir</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="index.php">Toko Rahma</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="pelanggan.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Pelanggan
                        </a>
                        <a class="nav-link" href="produk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Produk/Barang
                        </a>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#stokMenu" aria-expanded="false" aria-controls="stokMenu">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Stok
                            <i class="fas fa-chevron-down ms-auto"></i>
                        </a>
                        <div class="collapse" id="stokMenu">
                            <a class="nav-link" href="stok_masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-down"></i></div>
                                Stok Masuk
                            </a>
                            <a class="nav-link" href="stok_keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-up"></i></div>
                                Stok Keluar
                            </a>
                        </div>

                        <a class="nav-link" href="pembelian.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Pembelian
                        </a>
                        <a class="nav-link" href="keranjang.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Keranjang
                        
                        </a>
                         <a class="nav-link" href="laporan_transaksi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Laporan Transaksi
                        <a class="nav-link" href="user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            User
                        </a>
                        <a class="nav-link" href="logout.php.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Logout
                        </a>
                    </div>
            </nav>
        </div>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            
                        </ol>
                        <div class="row">
    <!-- Kartu Total Pelanggan -->
    <div class="col-xl-3 col-md-6">
        <div class="card bg-primary text-white mb-4 shadow-lg" style="background: rgba(0, 123, 255, 0.8);">
            <div class="card-body d-flex justify-content-between align-items-center">
                <i class="fas fa-users fa-3x"></i>
                <div class="text-right">
                    <h4>
                        <?php
                            echo mysqli_num_rows(mysqli_query($conn, "SELECT * FROM pelanggan")) . " Total pelanggan";
                        ?>
                    </h4>
                </div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                
                
            </div>
        </div>
    </div>

    <!-- Kartu Total Produk -->
    <div class="col-xl-3 col-md-6">
        <div class="card bg-warning text-white mb-4 shadow-lg" style="background: rgba(0, 193, 7, 0.8);">
            <div class="card-body d-flex justify-content-between align-items-center">
                <i class="fas fa-box fa-3x"></i>
                <div class="text-right">
                    <h4>
                        <?php
                            echo mysqli_num_rows(mysqli_query($conn, "SELECT * FROM produk")) . " Total produk";
                        ?>
                    </h4>
                </div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
               
            </div>
        </div>
    </div>

    <!-- Kartu Total Stok Masuk -->
    <div class="col-xl-3 col-md-6">
        <div class="card bg-success text-white mb-4 shadow-lg" style="background: rgba(40, 167, 69, 0.8);">
            <div class="card-body d-flex justify-content-between align-items-center">
                <i class="fas fa-arrow-up fa-3x"></i>
                <div class="text-right">
<?php
$stok_masuk = mysqli_query($conn, "SELECT SUM(stok) AS total_masuk FROM stok_masuk");

if (!$stok_masuk) {
    die("Query error: " . mysqli_error($conn)); // Menampilkan error SQL
}

$stok_masuk_data = mysqli_fetch_assoc($stok_masuk);
echo $stok_masuk_data['total_masuk'] . " Stok Masuk";
?>

                </div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                
            </div>
        </div>
    </div>

    <!-- Kartu Total Stok Keluar -->
    <div class="col-xl-3 col-md-6">
        <div class="card bg-danger text-white mb-4 shadow-lg" style="background: rgba(220, 53, 69, 0.8);">
            <div class="card-body d-flex justify-content-between align-items-center">
                <i class="fas fa-arrow-down fa-3x"></i>
                <div class="text-right">
                <?php
$stok_keluar = mysqli_query($conn, "SELECT SUM(jumlah) AS total_keluar FROM stok_keluar");
$stok_keluar_data = mysqli_fetch_assoc($stok_keluar);
echo $stok_keluar_data['total_keluar'] . " Stok Keluar";
?>

                </div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
               
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
    </body>
</html>
