<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_kasir");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data kategori
$sql_kategori = "SELECT * FROM kategori";
$result_kategori = $conn->query($sql_kategori);

// Tambah data produk
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_barang = $_POST['id_barang'];
    $kategori = $_POST['kategori'];
    $nama_barang = $_POST['nama_barang'];
    $stok = $_POST['stok'];
    $harga_beli = $_POST['harga_beli'];
    $harga_jual = $_POST['harga_jual'];
    $satuan = $_POST['satuan'];

    $sql = "INSERT INTO produk (id_barang, kategori, nama_barang, stok, harga_beli, harga_jual, satuan) 
            VALUES ('$id_barang', '$kategori', '$nama_barang', '$stok', '$harga_beli', '$harga_jual', '$satuan')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Data berhasil ditambahkan!');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Produk</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h1 class="text-center mb-4">Input Produk</h1>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="id_barang" class="form-label">ID Barang</label>
                <input type="text" class="form-control" id="id_barang" name="id_barang" required>
            </div>
            <div class="mb-3">
                <label for="kategori" class="form-label">Kategori</label>
                <select class="form-control" id="kategori" name="kategori" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php
                    if ($result_kategori->num_rows > 0) {
                        while ($row_kategori = $result_kategori->fetch_assoc()) {
                            echo "<option value='{$row_kategori['nama_kategori']}'>{$row_kategori['nama_kategori']}</option>";
                        }
                    } else {
                        echo "<option value=''>Kategori belum tersedia</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="nama_barang" class="form-label">Nama Barang</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
            </div>
            <div class="mb-3">
                <label for="stok" class="form-label">Stok</label>
                <input type="number" class="form-control" id="stok" name="stok" required>
            </div>
            <div class="mb-3">
                <label for="harga_beli" class="form-label">Harga Beli</label>
                <input type="number" class="form-control" id="harga_beli" name="harga_beli" required>
            </div>
            <div class="mb-3">
                <label for="harga_jual" class="form-label">Harga Jual</label>
                <input type="number" class="form-control" id="harga_jual" name="harga_jual" required>
            </div>
            <div class="mb-3">
                <label for="satuan" class="form-label">Satuan</label>
                <input type="text" class="form-control" id="satuan" name="satuan" required>
            </div>
            <button type="submit" class="btn btn-primary">Tambah Data</button>
            <a href="hasil_produk.php" class="btn btn-secondary">Lihat Data Produk</a>
        </form>
    </div>
</body>
</html>
