<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Hapus produk dari keranjang
if (isset($_GET['hapus'])) {
    $id_produk = $_GET['hapus'];
    unset($_SESSION['keranjang'][$id_produk]);
    $_SESSION['notif'] = "Produk telah dihapus dari keranjang!";
    header("Location: keranjang.php");
    exit;
}


if (isset($_POST['checkout'])) {
    $uang_dibayar = $_POST['uang_dibayar'];
    $id_pelanggan = $_POST['id_pelanggan']; // Mendapatkan ID pelanggan yang dipilih
    
    // Validasi apakah uang yang dibayar valid
    if ($uang_dibayar <= 0) {
        $error = "Jumlah uang yang dibayar harus lebih besar dari 0.";
    } else {
        $total_harga = array_sum(array_map(function ($item) {
            return $item['harga'] * $item['jumlah'];
        }, $_SESSION['keranjang']));

        if ($uang_dibayar >= $total_harga) {
            $kembalian = $uang_dibayar - $total_harga;

            // Perbarui stok di database dengan prepared statement
            foreach ($_SESSION['keranjang'] as $item) {
                $id_produk = $item['id_produk']; // Asumsikan ada ID produk di data keranjang
                $jumlah_beli = $item['jumlah'];

                // Menggunakan prepared statement untuk menghindari SQL injection
                $stmt = $conn->prepare("UPDATE produk SET stok = stok - ? WHERE id_produk = ?");
                $stmt->bind_param("ii", $jumlah_beli, $id_produk);
                $stmt->execute();

                if ($stmt->affected_rows === 0) {
                    die("Gagal memperbarui stok: Produk tidak ditemukan atau stok tidak cukup.");
                }
            }

            // Simpan transaksi ke sesi
            $_SESSION['transaksi'] = [
                'keranjang' => $_SESSION['keranjang'],
                'total_harga' => $total_harga,
                'uang_dibayar' => $uang_dibayar,
                'kembalian' => $kembalian,
                'id_pelanggan' => $id_pelanggan, // Menyimpan ID pelanggan yang dipilih
                'waktu' => date('Y-m-d H:i:s')
            ];

            // Kosongkan keranjang
            unset($_SESSION['keranjang']);

            header('Location: struk.php');
            exit;
        } else {
            $error = "Uang yang dibayar tidak cukup.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Keranjang Belanja</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
<style>
    /* Styling untuk tabel keranjang */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

table th, table td {
    padding: 12px;
    text-align: center;
    border: 1px solid #ddd;
}

table th {
    background-color: #4CAF50;
    color: white;
}

table td {
    background-color: #f2f2f2;
}

table td img {
    width: 50px;
    height: auto;
}

/* Styling form checkout agar tampilannya rapi */
.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
}

.form-group select, .form-group input {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

/* Styling untuk tombol */
button {
    padding: 10px 20px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #45a049;
}

/* Styling untuk keranjang dan checkout agar lebih rapi dan terstruktur */
.checkout-section {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.checkout-section > * {
    margin-bottom: 15px;
}

.checkout-section label {
    font-weight: bold;
}

</style>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="index.php">Aplikasi Kasir</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="pelanggan.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Pelanggan
                        </a>
                        <a class="nav-link" href="produk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Produk/Barang
                        </a>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#stokMenu" aria-expanded="false" aria-controls="stokMenu">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Stok
                            <i class="fas fa-chevron-down ms-auto"></i>
                        </a>
                        <div class="collapse" id="stokMenu">
                            <a class="nav-link" href="stok_masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-down"></i></div>
                                Stok Masuk
                            </a>
                            <a class="nav-link" href="stok_keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-up"></i></div>
                                Stok Keluar
                            </a>
                        </div>

                        <a class="nav-link" href="pembelian.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Pembelian
                        </a>
                        <a class="nav-link" href="keranjang.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Keranjang
                        </a>
                        <a class="nav-link" href="user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            User
                        </a>
                
                         <a class="nav-link" href="laporan_transaksi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Laporan Transaksi
                        </a>
                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Logout
                        </a>
                    </div>
                
            </nav>
        </div>

        <!-- Main Content -->
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Keranjang Belanja</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item">
                            <a href="?page=keranjang" class="btn btn-danger">Kembali</a>
                        </li>
                    </ol>

                   <?php if (isset($_SESSION['notif'])): ?>
    <div class="alert alert-success"><?= $_SESSION['notif'] ?></div>
    <?php unset($_SESSION['notif']); ?>
<?php endif; ?>

<table border="1">
    <tr>
        <th>Nama Produk</th>
        <th>Harga</th>
        <th>Jumlah</th>
        <th>Total</th>
        <th>Aksi</th>
    </tr>
<?php 

$total = 0;

// Pastikan $_SESSION['keranjang'] sudah ada dan berupa array
if (!isset($_SESSION['keranjang']) || !is_array($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = []; // Inisialisasi array kosong
}

foreach ($_SESSION['keranjang'] as $produk) :
    $subtotal = $produk['harga'] * $produk['jumlah'];
    $total += $subtotal;
?>
    <tr>
        <td><?= $produk['nama_produk'] ?></td>
        <td>Rp <?= number_format($produk['harga'], 0, ',', '.') ?></td>
        <td><?= $produk['jumlah'] ?></td>
        <td>Rp <?= number_format($subtotal, 0, ',', '.') ?></td>
        <td><a href="keranjang.php?hapus=<?= $produk['id_produk'] ?>" class="btn btn-danger">Hapus</a></td>
    </tr>
<?php endforeach; ?>

    <tr>
        <td colspan="3"><strong>Total Harga</strong></td>
        <td><strong>Rp <?= number_format($total, 0, ',', '.') ?></strong></td>
        <td></td>
    </tr>
</table>

                    <!-- Checkout -->
<!-- Checkout Section -->
<div class="checkout-section">
    <!-- Form Checkout -->
    <form method="POST" action="keranjang.php">
        <div class="form-group">
            <label for="id_pelanggan">Nama Pelanggan:</label>
            <select name="id_pelanggan" required>
                <?php
                // Ambil daftar pelanggan dari database
                $pelanggan_query = mysqli_query($conn, "SELECT id_pelanggan, nama_pelanggan FROM pelanggan");
                 while ($pelanggan = mysqli_fetch_assoc($pelanggan_query)) {
                    echo "<option value=\"{$pelanggan['id_pelanggan']}\">{$pelanggan['nama_pelanggan']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label for="uang_dibayar">Uang yang Dibayar:</label>
            <input type="number" name="uang_dibayar" required>
        </div>

        <button type="submit" name="checkout">Proses Pembayaran</button>
    </form>

    <!-- Menampilkan pesan error jika ada -->
    <?php if (isset($error)) { ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php } ?>




                    
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
