<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Periksa apakah tabel laporan_transaksi ada
$check_table = mysqli_query($conn, "SHOW TABLES LIKE 'laporan_transaksi'");
if (mysqli_num_rows($check_table) == 0) {
    die("Error: Table ");
}

// Ambil data transaksi dari sesi
$transaksi = isset($_SESSION['transaksi']) ? $_SESSION['transaksi'] : [];
$id_pelanggan = isset($transaksi['id_pelanggan']) ? $transaksi['id_pelanggan'] : 'Tidak tersedia';
$nama_pelanggan = isset($transaksi['nama_pelanggan']) ? $transaksi['nama_pelanggan'] : 'Tidak tersedia';

// Debugging ID Pelanggan dan Nama Pelanggan
echo "ID Pelanggan: " . $id_pelanggan . "<br>";
echo "Nama Pelanggan: " . $nama_pelanggan . "<br>";

// Filter Bulan dan Tahun
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : '';
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : '';

$query_laporan = "SELECT * FROM laporan_transaksi WHERE 1=1";

if (!empty($bulan)) {
    $query_laporan .= " AND MONTH(tanggal) = '$bulan'";
}
if (!empty($tahun)) {
    $query_laporan .= " AND YEAR(tanggal) = '$tahun'";
}

// Eksekusi query
$result = mysqli_query($conn, $query_laporan);

if (!$result) {
    die("Query gagal: " . mysqli_error($conn));
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #f4f4f4;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 10px;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: #333;
            display: block;
        }

        .sidebar ul li a:hover {
            background-color: #ddd;
        }

        /* Konten utama */
        .content {
            margin-left: 260px;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }

        table th {
            background-color: #007bff;
        }
    </style>
</head>
<body class="sb-nav-fixed">

    <!-- Top Navigation Bar -->
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="index.php">Kasir Rahma</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    </nav>

    <!-- Main Layout -->
    <div id="layoutSidenav">
        <!-- Sidebar -->
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="pelanggan.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Pelanggan
                        </a>
                        <a class="nav-link" href="produk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Produk/Barang
                        </a>
                        <a class="nav-link" href="stok_masuk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-arrow-down"></i></div>
                            Stok Masuk
                        </a>
                        <a class="nav-link" href="stok_keluar.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-arrow-up"></i></div>
                            Stok Keluar
                        </a>
                        <a class="nav-link" href="pembelian.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Pembelian
                        </a>
                        <a class="nav-link" href="keranjang.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Keranjang
                              </a>
                        <a class="nav-link" href="laporan_transaksi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Laporan Transaksi
                        </a>
                        <a class="nav-link" href="user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            User
                        </a>
                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Logout
                        </a>
                    </div>

            </nav>
        </div>

        <!-- Main Content -->
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h2>Laporan Transaksi Kasir</h2>

                    <!-- Form Filter Bulan dan Tahun -->
                    <form method="GET" action="">
                        <label for="bulan">Pilih Bulan:</label>
                        <select name="bulan" id="bulan">
                            <option value="">Semua</option>
                            <?php for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= isset($_GET['bulan']) && $_GET['bulan'] == $i ? 'selected' : '' ?>>
                                    <?= date('F', mktime(0, 0, 0, $i, 10)) ?>
                                </option>
                            <?php endfor; ?>
                        </select>

                        <label for="tahun">Pilih Tahun:</label>
                        <select name="tahun" id="tahun">
                            <option value="">Semua</option>
                            <?php
                            $currentYear = date('Y');
                            for ($i = $currentYear; $i >= $currentYear - 10; $i--): ?>
                                <option value="<?= $i ?>" <?= isset($_GET['tahun']) && $_GET['tahun'] == $i ? 'selected' : '' ?>>
                                    <?= $i ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                        <button type="submit">Filter</button>
                    </form>

                   <table id="tabelLaporan">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Pelanggan</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1; 
                $totalKeseluruhan = 0;
                while ($row = mysqli_fetch_assoc($result)): 
                    $totalKeseluruhan += $row['total'];
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= $row['nama_pelanggan'] ?></td>
                    <td><?= $row['nama_produk'] ?></td>
                    <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                    <td><?= $row['jumlah'] ?></td>
                    <td>Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
                    <td><?= $row['tanggal'] ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="5" style="text-align: right;">Total Keseluruhan:</th>
                    <th colspan="2">Rp <?= number_format($totalKeseluruhan, 0, ',', '.') ?></th>
                </tr>
            </tfoot>
        </table>

        <div style="margin-top: 20px;">
            <button onclick="printReport()" style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; cursor: pointer;">
                Cetak Laporan
            </button>
        </div>

                </div>
            </main>
        </div>
    </div>
</body>
</html>

<script>
    function printReport() {
       <script>
    function printReport() {
        var originalContents = document.body.innerHTML; // Simpan konten asli halaman
        var tableContents = document.getElementById('tabelLaporan').outerHTML; // Ambil konten tabel

        // Hapus semua elemen di luar tabel
        document.body.innerHTML = tableContents;

        // Panggil fungsi print
        window.print();

        // Kembalikan halaman ke kondisi semula setelah print selesai
        document.body.innerHTML = originalContents;
    }
</script>
</html>
</body>
