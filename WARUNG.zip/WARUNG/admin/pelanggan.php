<?php
$conn = new mysqli('localhost', 'root', '', 'kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data pelanggan
$sql = "SELECT * FROM pelanggan";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>kasir</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
    /* Styling untuk tabel pelanggan */
table.table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 20px;
    font-family: Arial, sans-serif;
}

table.table thead th {
    background-color: #4CAF50;
    color: white;
    text-align: center;
    padding: 10px;
    border: 1px solid #ddd;
}

table.table tbody td {
    padding: 10px;
    text-align: center;
    border: 1px solid #ddd;
}

table.table tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

table.table tbody tr:hover {
    background-color: #e2e2e2;
}

table.table .btn {
    padding: 5px 10px;
    font-size: 14px;
}

table.table .btn-secondary {
    background-color: #6c757d;
    border-color: #6c757d;
    color: white;
}

table.table .btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
    color: white;
}

table.table .btn-secondary:hover,
table.table .btn-danger:hover {
    opacity: 0.8;
    transition: 0.3s;
}

/* Responsive styling */
@media screen and (max-width: 768px) {
    table.table thead {
        display: none;
    }

    table.table tbody td {
        display: block;
        text-align: left;
        border: none;
        padding: 8px 10px;
    }

    table.table tbody td:before {
        content: attr(data-label);
        font-weight: bold;
        display: block;
        margin-bottom: 5px;
    }

    table.table tbody tr {
        margin-bottom: 10px;
        display: block;
    }

</style>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="index.php">Toko Rahma</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="?page=pelanggan.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Pelanggan
                        </a>
                        <a class="nav-link" href="produk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Produk/Barang
                        </a>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#stokMenu" aria-expanded="false" aria-controls="stokMenu">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Stok
                            <i class="fas fa-chevron-down ms-auto"></i>
                        </a>
                        <div class="collapse" id="stokMenu">
                            <a class="nav-link" href="stok_masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-down"></i></div>
                                Stok Masuk
                            </a>
                            <a class="nav-link" href="stok_keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-up"></i></div>
                                Stok Keluar
                            </a>
                        </div>

                        <a class="nav-link" href="pembelian.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Pembelian
                        </a>
                        <a class="nav-link" href="keranjang.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Keranjang
                        </a>
                        <a class="nav-link" href="user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            User
                         </a>
                         <a class="nav-link" href="laporan_transaksi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Laporan Transaksi
                        </a>
                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Logout
                        </a>
                    </div>
                </div>
            
            </nav>
        </div>

            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Pelanggan</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Pelanggan</li>
                        </ol>
                        <a href="pelanggan_tambah.php" class="btn btn-primary">+ Tambah Data</a>
<hr>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Pelanggan</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Jenis Kelamin</th>
            <th>No Telepon</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($result->num_rows > 0) {
            $no = 1;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $no++ . "</td>
                        <td>" . $row['nama_pelanggan'] . "</td>
                        <td>" . $row['email'] . "</td>
                        <td>" . $row['alamat'] . "</td>
                        <td>" . $row['jenis_kelamin'] . "</td>
                        <td>" . $row['no_telepon'] . "</td>
                        <td>
                            <a href='pelanggan_ubah.php?id=" . $row['id_pelanggan'] . "' class='btn btn-warning btn-sm'>Ubah</a>
                            <a href='pelanggan_hapus.php?id=" . $row['id_pelanggan'] . "' class='btn btn-danger btn-sm' onclick=\"return confirm('Yakin ingin menghapus data ini?')\">Hapus</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='7' class='text-center'>Tidak ada data pelanggan.</td></tr>";
        }
        ?>
    </tbody>
</table>

<!-- Bootstrap dan Script -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="js/scripts.js"></script>
