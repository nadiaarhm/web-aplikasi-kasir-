<?php 
// Termasuk file koneksi
include 'koneksi.php'; 

// Ambil ID dari URL dan pastikan valid
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    // Query untuk menghapus data pelanggan berdasarkan ID
    $query = mysqli_query($koneksi, "DELETE FROM pelanggan WHERE id_pelanggan = $id");

    // Cek apakah query berhasil
    if ($query) {
        echo '<script>alert("Hapus data berhasil"); window.location.href = "pelanggan.php";</script>';
    } else {
        echo '<script>alert("Hapus data gagal");</script>';
    }
} else {
    echo '<script>alert("ID tidak valid"); window.location.href = "pelanggan.php";</script>';
}
?>
