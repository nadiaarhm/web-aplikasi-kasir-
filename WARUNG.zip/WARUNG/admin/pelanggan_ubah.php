<?php 
include_once "koneksi.php"; 

// Cek jika pengguna belum login
if (!isset($_SESSION['user'])) {
    header('location:login.php');
    exit;
}

// Ambil id pelanggan dari URL jika ada
if (isset($_GET['id'])) {
    $id_pelanggan = $_GET['id'];

    // Ambil data pelanggan berdasarkan id
    $query = mysqli_query($koneksi, "SELECT * FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'");
    $data = mysqli_fetch_assoc($query);
} 

// Proses update data pelanggan
if (isset($_POST['update'])) {
    $nama_pelanggan = $_POST['nama_pelanggan'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $no_telepon = $_POST['no_telepon'];

    $update_query = mysqli_query($koneksi, "UPDATE pelanggan SET
        nama_pelanggan = '$nama_pelanggan',
        email = '$email',
        alamat = '$alamat',
        jenis_kelamin = '$jenis_kelamin',
        no_telepon = '$no_telepon'
        WHERE id_pelanggan = '$id_pelanggan'");

    if ($update_query) {
        $_SESSION['notif'] = "Data pelanggan berhasil diperbarui!";
    } else {
        $_SESSION['notif'] = "Terjadi kesalahan, gagal memperbarui data pelanggan.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>kasir</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="index.php">Toko Rahma</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="pelanggan.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Pelanggan
                        </a>
                        <a class="nav-link" href="produk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Produk/Barang
                        </a>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#stokMenu" aria-expanded="false" aria-controls="stokMenu">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Stok
                            <i class="fas fa-chevron-down ms-auto"></i>
                        </a>
                        <div class="collapse" id="stokMenu">
                            <a class="nav-link" href="stok_masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-down"></i></div>
                                Stok Masuk
                            </a>
                            <a class="nav-link" href="stok_keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-up"></i></div>
                                Stok Keluar
                            </a>
                        </div>

                        <a class="nav-link" href="pembelian.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Pembelian
                        </a>
                        <a class="nav-link" href="keranjang.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Keranjang
                        </a>
                        <a class="nav-link" href="user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            User
                        </a>
                         <a class="nav-link" href="laporan_transaksi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Laporan Transaksi
                        </a>
                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Logout
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>
                    <?php echo $_SESSION['user']['nama']; ?>
                </div>
            </nav>
        </div>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Ubah Data Pelanggan</h1>
                    <ol class="breadcrumb mb-4">
                    
                    </ol>

                    <?php if (isset($_SESSION['notif'])): ?>
                        <div class='alert alert-success'><?= $_SESSION['notif']; ?></div>
                        <?php unset($_SESSION['notif']); ?>
                    <?php endif; ?>

                   <form method="POST" action="">
    <div class="form-group mb-3">
        <label for="nama_pelanggan">Nama Pelanggan</label>
        <input type="text" class="form-control" id="nama_pelanggan" name="nama_pelanggan" 
        value="<?php echo isset($data['nama_pelanggan']) ? htmlspecialchars($data['nama_pelanggan']) : ''; ?>" required>
    </div>

    <div class="form-group mb-3">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" 
        value="<?php echo isset($data['email']) ? htmlspecialchars($data['email']) : ''; ?>" required>
    </div>

    <div class="form-group mb-3">
        <label for="alamat">Alamat</label>
        <textarea class="form-control" id="alamat" name="alamat" required><?php echo isset($data['alamat']) ? htmlspecialchars($data['alamat']) : ''; ?></textarea>
    </div>

    <div class="form-group mb-3">
        <label for="jenis_kelamin">Jenis Kelamin</label>
        <select class="form-control" id="jenis_kelamin" name="jenis_kelamin" required>
            <option value="Laki-laki" <?php echo isset($data['jenis_kelamin']) && $data['jenis_kelamin'] === 'Laki-laki' ? 'selected' : ''; ?>>Laki-laki</option>
            <option value="Perempuan" <?php echo isset($data['jenis_kelamin']) && $data['jenis_kelamin'] === 'Perempuan' ? 'selected' : ''; ?>>Perempuan</option>
        </select>
    </div>

    <div class="form-group mb-3">
        <label for="no_telepon">No Telepon</label>
        <input type="text" class="form-control" id="no_telepon" name="no_telepon" 
        value="<?php echo isset($data['no_telepon']) ? htmlspecialchars($data['no_telepon']) : ''; ?>" required>
    </div>

    <button type="submit" class="btn btn-primary mt-3" name="update">Update</button>
    <a href="pelanggan.php" class="btn btn-danger mt-3">Kembali ke Pelanggan</a>
</form>

                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
