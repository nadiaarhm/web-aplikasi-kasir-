<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if (!isset($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = [];
}

// Tambahkan barang ke keranjang
if (isset($_POST['add_to_cart'])) {
    $id_produk = $_POST['id_produk'];
    $jumlah = $_POST['jumlah'];

    $query = mysqli_query($conn, "SELECT * FROM produk WHERE id_produk = '$id_produk'");
    $produk = mysqli_fetch_assoc($query);

    if ($produk) {
        $produk['jumlah'] = $jumlah;
        $_SESSION['keranjang'][$id_produk] = $produk;
        $_SESSION['notif'] = "Produk telah ditambahkan ke keranjang!";
    }
    header("Location: pembelian.php");
    exit;
}



// Checkout
if (isset($_POST['checkout'])) {
    $uang_dibayar = $_POST['uang_dibayar'];
    $total_harga = array_sum(array_map(function ($item) {
        return $item['harga'] * $item['jumlah'];
    }, $_SESSION['keranjang']));

    if ($uang_dibayar >= $total_harga) {
        $kembalian = $uang_dibayar - $total_harga;
        $_SESSION['total_harga'] = $total_harga;
        $_SESSION['kembalian'] = $kembalian;
        header('Location: struk.php');
        exit;
    } else {
        $error = "Uang yang dibayar tidak cukup.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>kasir</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <style>
        /* Styling tambahan untuk tabel hasil kategori */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table th, table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #4CAF50;
            color: white;
        }
        table td {
            background-color: #f2f2f2;
        }
        table td img {
            width: 50px;
            height: auto;
        }
        /* Styling untuk card produk */
.card {
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    max-width: 250px; /* Membatasi lebar card */
    margin: 0 auto; /* Mengatur margin untuk pusat */
}

.card img {
    height: 150px; /* Ukuran gambar yang lebih kecil */
    object-fit: cover;
    border-bottom: 1px solid #ddd;
}

.card-body {
    padding: 12px; /* Mengurangi padding agar tidak terlalu lebar */
}

.card-title {
    font-size: 16px; /* Mengurangi ukuran font */
    font-weight: bold;
    color: #333;
}

.card-text {
    font-size: 14px; /* Mengurangi ukuran font harga */
    color: #007BFF;
    margin-bottom: 10px;
}

button.btn {
    font-size: 14px; /* Mengurangi ukuran tombol */
    font-weight: bold;
}

.row {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.col-md-4 {
    flex: 0 0 30%; /* Mengatur lebar kolom untuk 3 kolom di desktop */
    max-width: 30%; /* Membatasi lebar maksimal kolom */
    margin: 10px; /* Menambahkan jarak antar card */
}

@media (max-width: 768px) {
    .col-md-4 {
        flex: 0 0 48%; /* Mengatur dua kolom di layar kecil */
        max-width: 48%;
    }
}

@media (max-width: 480px) {
    .col-md-4 {
        flex: 0 0 100%; /* Satu kolom di layar sangat kecil */
        max-width: 100%;
    }
}

    </style>
</head>
<body class="sb-nav-fixed">
    <!-- Top Navigation -->
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="index.php">Toko Rahma</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#"><i class="fas fa-bars"></i></button>
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="#!">Settings</a></li>
                    <li><a class="dropdown-item" href="#!">Activity Log</a></li>
                    <li><hr class="dropdown-divider" /></li>
                    <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <!-- Main Layout -->
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="pelanggan.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Pelanggan
                        </a>
                        <a class="nav-link" href="produk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Produk/Barang
                        </a>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#stokMenu" aria-expanded="false" aria-controls="stokMenu">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Stok
                            <i class="fas fa-chevron-down ms-auto"></i>
                        </a>
                        <div class="collapse" id="stokMenu">
                            <a class="nav-link" href="stok_masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-down"></i></div>
                                Stok Masuk
                            </a>
                            <a class="nav-link" href="stok_keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-up"></i></div>
                                Stok Keluar
                            </a>
                        </div>

                        <a class="nav-link" href="pembelian.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Pembelian
                        </a>
                        <a class="nav-link" href="keranjang.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Keranjang
                        </a>
                        <a class="nav-link" href="user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            User
                         </a>
                         <a class="nav-link" href="laporan_transaksi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Laporan Transaksi
                        </a>
                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Logout
                        </a>
                    </div>

            </nav>
        </div>
        <!-- Main Content -->
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Pembelian</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item">
                           
                    </ol>

                    <!-- Form Pencarian Kategori -->
                    <form method="GET" action="pembelian.php">
                        <input type="text" name="kategori" placeholder="Cari kategori barang" value="<?= isset($_GET['kategori']) ? $_GET['kategori'] : '' ?>">
                        <button type="submit">Cari</button>
                    </form>
                    <hr>
                    
                    <!-- Tampilkan Notifikasi -->
                    <?php
                    if (isset($_SESSION['notif'])) {
                        echo "<div class='alert alert-success'>{$_SESSION['notif']}</div>";
                        unset($_SESSION['notif']);
                    }
                    ?>

                    <!-- Produk Berdasarkan Kategori -->
<?php
if (isset($_GET['kategori']) && !empty($_GET['kategori'])) {
    $kategori = mysqli_real_escape_string($conn, $_GET['kategori']);
    $query = mysqli_query($conn, "SELECT * FROM produk WHERE kategori LIKE '%$kategori%'");

    if (mysqli_num_rows($query) > 0) {
        echo "<h2>Produk Kategori: $kategori</h2>";
        echo '<div class="row">'; // Membuka div row untuk grid produk

        while ($data = mysqli_fetch_assoc($query)) {
            echo '<div class="col-md-4 mb-4">'; // Setiap produk menjadi kolom di dalam grid
            echo '<div class="card" style="width: 100%;">';
            echo "<img src='uploads/{$data['gambar']}' class='card-img-top' alt='{$data['nama_produk']}'>";
            echo '<div class="card-body">';
            echo "<h5 class='card-title'>{$data['nama_produk']}</h5>";
            echo "<p class='card-text'>Rp " . number_format($data['harga'], 0, ',', '.') . "</p>";
            echo '<form method="POST" action="">';
            echo "<input type='hidden' name='id_produk' value='{$data['id_produk']}'>";
            echo "<input type='number' name='jumlah' min='1' max='{$data['stok']}' value='1' class='form-control mb-2'>";
            echo "<button type='submit' name='add_to_cart' class='btn btn-primary w-100'>Tambah ke Keranjang</button>";
            echo '</form>';
            echo '</div>';
            echo '</div>';
            echo '</div>'; // Menutup col-md-4
        }

        echo '</div>'; // Menutup div row
    } else {
        echo "<p>Tidak ada produk untuk kategori: $kategori</p>";
    }
}
?>

                    
                    
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
