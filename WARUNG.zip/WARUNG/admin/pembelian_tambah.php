<?php
if (isset($_POST['id_pelanggan'])) {
    
    $id_pelanggan = $_POST['id_pelanggan'];
    $produk = $_POST['produk'];

    $total = 0;
    $tanggal = date('Y/m/d');

    $query = mysqli_query($conn, "INSERT INTO penjualan(tanggal_penjualan, id_penjualan) VALUES('$tanggal', '$id_pelanggan')");

    $idTerakhir = mysqli_fetch_array(mysqli_query($conn, "SELECT*FROM penjualan ORDER BY id_penjualan DESC"));
     $id_penjualan = $idTerakhir['id_penjualan'];

    foreach ($produk as $key => $val) {
        $pr = mysqli_fetch_array(mysql_query($conn, "SELECT*FROM produk where id_produk=$key"));

        $id_penjualan = $idTerakhir['id_penjualan'];
        $sub = $val * $pr['harga'];
        $total += $sub;
        $query = mysqli_query($conn, "INSERT INTO detail_penjualan(id_penjualan, id_produk, jumlah_produk, sub_total) VALUES('$id_penjualan', '$key','$val', '$sub')");

        
    }

     $query = mysqli_query($conn, "UPDATE penjualan SET total_harga=$total WHERE id_penjualan=$id_penjualan");

    if ($query) {
        echo '<script>alert("Tambah data berhasil")</script>';
    } else {
        echo '<script>alert("Tambah data gagal")</script>';
    }
}
?>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="pelanggan.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Pelanggan
                        </a>
                        <a class="nav-link" href="produk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Produk/Barang
                        </a>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#stokMenu" aria-expanded="false" aria-controls="stokMenu">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Stok
                            <i class="fas fa-chevron-down ms-auto"></i>
                        </a>
                        <div class="collapse" id="stokMenu">
                            <a class="nav-link" href="stok_masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-down"></i></div>
                                Stok Masuk
                            </a>
                            <a class="nav-link" href="stok_keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-up"></i></div>
                                Stok Keluar
                            </a>
                        </div>

                        <a class="nav-link" href="pembelian.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Pembelian
                        </a>
                        <a class="nav-link" href="keranjang.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Keranjang
                        </a>
                        <a class="nav-link" href="user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            User
                         </a>
                         <a class="nav-link" href="laporan_transaksi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Laporan Transaksi
                        </a>
                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Logout
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>
                    <?php echo $_SESSION['user']['nama']; ?>
                </div>
            </nav>
        </div>

    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Pembelian</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Pembelian</li>
                </ol>
                <a href="?page=produk" class="btn btn-danger">Kembali</a>
                <hr>
                <form method="post">
                    <table class="table table-bordered" style="width: 100%;">
                        <tr>
                            <td style="width: 200px;">Nama Pelanggan</td>
                            <td style="width: 1%;">:</td>
                            <td>
                                <select class="form-control form-select" name="id_pelanggan" style="width: 100%;" required>
                                    <?php 
                                    $p = mysqli_query($conn, "SELECT * FROM pelanggan");
                                    while ($pel = mysqli_fetch_array($p)) {
                                    ?>
                                    <option value="<?php echo $pel['id_pelanggan']; ?>"><?php echo $pel['nama_pelanggan']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <?php
                        $pro = mysqli_query($conn, "SELECT * FROM produk");
                        while ($produk = mysqli_fetch_array($pro)) {
                        ?>
                        <tr>
                            <td><?php echo $produk['nama_produk'] . ' (stok : '.$produk['stok'].')'; ?></td>
                            <td>:</td>
                            <td>
                                <input class="form-control" type="number" 
                                step="1" min="0" max="<?php echo $produk['stok']; ?>" 
                                value="0" name="produk[<?php echo $produk['id_produk']; ?>]">
                            </td>
                        </tr>
                        <?php
                        }
                        ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                                <button type="reset" class="btn btn-danger">Reset</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </main>
    </div>
</div> 