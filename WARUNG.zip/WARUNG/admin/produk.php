<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>kasir</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    
    <style>
    /* Styling untuk tabel pelanggan */
    table.table {
        border-collapse: collapse;
        width: 100%;
        margin-top: 20px;
        font-family: Arial, sans-serif;
    }

    table.table thead th {
        background-color: #4CAF50;
        color: white;
        text-align: center;
        padding: 10px;
        border: 1px solid #ddd;
    }

    table.table tbody td {
        padding: 10px;
        text-align: center;
        border: 1px solid #ddd;
    }

    table.table tbody tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    table.table tbody tr:hover {
        background-color: #e2e2e2;
    }

    table.table .btn {
        padding: 5px 10px;
        font-size: 14px;
    }

    table.table .btn-secondary {
        background-color: #6c757d;
        border-color: #6c757d;
        color: white;
    }

    table.table .btn-danger {
        background-color: #dc3545;
        border-color: #dc3545;
        color: white;
    }

    table.table .btn-secondary:hover,
    table.table .btn-danger:hover {
        opacity: 0.8;
        transition: 0.3s;
    }

    /* Responsive styling */
    @media screen and (max-width: 768px) {
        table.table thead {
            display: none;
        }

        table.table tbody td {
            display: block;
            text-align: left;
            border: none;
            padding: 8px 10px;
        }

        table.table tbody td:before {
            content: attr(data-label);
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        table.table tbody tr {
            margin-bottom: 10px;
            display: block;
        }

    </style>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="index.php">Toko Rahma</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="pelanggan.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Pelanggan
                        </a>
                        <a class="nav-link" href="produk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Produk/Barang
                        </a>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#stokMenu" aria-expanded="false" aria-controls="stokMenu">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Stok
                            <i class="fas fa-chevron-down ms-auto"></i>
                        </a>
                        <div class="collapse" id="stokMenu">
                            <a class="nav-link" href="stok_masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-down"></i></div>
                                Stok Masuk
                            </a>
                            <a class="nav-link" href="stok_keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-up"></i></div>
                                Stok Keluar
                            </a>
                        </div>

                        <a class="nav-link" href="pembelian.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Pembelian
                        </a>
                        <a class="nav-link" href="keranjang.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Keranjang
                        </a>
                        <a class="nav-link" href="user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            User
                         </a>
                         <a class="nav-link" href="laporan_transaksi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Laporan Transaksi
                        </a>
                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Logout
                        </a>
                    </div>
        
            </nav>
        </div>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Produk</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Produk</li>
                    </ol>
                    <a href="produk_tambah.php" class="btn btn-primary">+ Tambah Data</a>
                    <hr>

                    <!-- Menampilkan notifikasi jika ada -->
                    <?php
                    if (isset($_SESSION['notif'])) {
                        echo '<div class="alert alert-info">' . $_SESSION['notif'] . '</div>';
                        unset($_SESSION['notif']); // Menghapus notifikasi setelah ditampilkan
                    }
                    ?>

<!-- Form Pencarian -->
                    <form method="GET" class="mb-3">
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" placeholder="Cari Nama Produk atau Kode Barang..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                            <button class="btn btn-primary" type="submit">Cari</button>
                             <a href="produk.php" class="btn btn-danger">Kembali</a>
                        </div>
                    </form>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Nama Produk</th>
                                <th>Harga</th>
                                <th>Harga Jual</th>
                                <th>Stok</th>
                                <th>Kategori</th>
                                <th>Kode Barang</th>
                                <th>Satuan</th>
                                <th>Gambar</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Filter pencarian
                            $search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

                          $query = mysqli_query($conn, "SELECT * FROM produk 
    WHERE nama_produk LIKE '%$search%' ");

                            if ($query) {
                                if (mysqli_num_rows($query) > 0) {
                                    while ($data = mysqli_fetch_array($query)) {
                            ?>
                            <tr>
                                <td><?php echo $data['nama_produk']; ?></td>
                                <td><?php echo number_format($data['harga'], 0, ',', '.'); ?></td>
                                <td><?php echo number_format($data['harga_jual'], 0, ',', '.'); ?></td>
                                <td><?php echo $data['stok']; ?></td>
                                <td><?php echo $data['kategori']; ?></td>
                                <td><?php echo $data['kode_barang']; ?></td>
                                <td><?php echo $data['satuan']; ?></td>
                                <td><img src="uploads/<?php echo $data['gambar']; ?>" alt="Gambar Produk" style="width: 100px;"></td>
                                <td>
                                    <!-- Menampilkan aksi Ubah dan Hapus -->
                                    <a href="produk_ubah.php?id_produk=<?php echo $data['id_produk']; ?>" class="btn btn-secondary">Ubah</a>
                                    <a href="produk_hapus.php?id_produk=<?php echo $data['id_produk']; ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                </td>
                            </tr>
                            <?php
                                    }
                                } else {
                                    echo '<tr><td colspan="9" class="text-center">Data tidak ditemukan</td></tr>';
                                }
                            } else {
                                echo '<tr><td colspan="9" class="text-center">Query gagal: ' . mysqli_error($conn) . '</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
