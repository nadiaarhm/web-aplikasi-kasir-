<?php
// Menyertakan file koneksi.php untuk memastikan koneksi database tersedia
include_once "koneksi.php"; 

// Cek apakah parameter 'id_produk' ada di URL
if (isset($_GET['id_produk'])) {
    $id_produk = $_GET['id_produk']; // Ambil nilai parameter 'id_produk'

    // Pastikan ID adalah angka untuk keamanan
    if (is_numeric($id_produk)) {
        // Query untuk menghapus data produk berdasarkan ID
        $query = mysqli_query($koneksi, "DELETE FROM produk WHERE id_produk = $id_produk");

        // Cek apakah query berhasil
        if ($query) {
            echo '<script>alert("Hapus data berhasil"); window.location.href = "produk.php";</script>';
        } else {
            echo '<script>alert("Hapus data gagal"); window.location.href = "produk.php";</script>';
        }
    } else {
        echo '<script>alert("ID tidak valid"); window.location.href = "produk.php";</script>';
    }
} else {
    echo '<script>alert("Parameter ID tidak ditemukan"); window.location.href = "produk.php";</script>';
}
?>
