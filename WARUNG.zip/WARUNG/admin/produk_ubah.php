<?php
include_once "koneksi.php";
if (!isset($_SESSION['user'])) {
    header('location:login.php');
}

if (isset($_GET['id_produk'])) {
    $id_produk = $_GET['id_produk'];
    $query = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk = $id_produk");
    $data = mysqli_fetch_assoc($query);
    if (!$data) {
        $_SESSION['notif'] = "Produk tidak ditemukan.";
        header("Location: produk.php");
        exit();
    }
} else {
    $_SESSION['notif'] = "ID produk tidak valid.";
    header("Location: produk.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama_produk'];
    $harga = $_POST['harga'];
    $harga_jual = $_POST['harga_jual'];
    $stok = $_POST['stok'];
    $kategori = $_POST['kategori'];
    $kode_barang = $_POST['kode_barang'];
    $satuan = $_POST['satuan'];

    // Mengubah gambar jika ada yang baru
    if ($_FILES['gambar']['error'] == 0) {
        $gambar = $_FILES['gambar']['name'];
        $tmp_name = $_FILES['gambar']['tmp_name'];
        $upload_dir = 'uploads/';
        move_uploaded_file($tmp_name, $upload_dir . $gambar);
    } else {
        $gambar = $data['gambar'];  // Gambar lama jika tidak ada gambar baru
    }

    // Update produk
    $update_query = "UPDATE produk SET nama_produk='$nama', harga='$harga', harga_jual=$harga_jual, stok='$stok', kategori='$kategori', kode_barang='$kode_barang', satuan='$satuan', gambar='$gambar' WHERE id_produk=$id_produk";
    if (mysqli_query($koneksi, $update_query)) {
        $_SESSION['notif'] = "Produk berhasil diperbarui!";
        header("Location: produk.php");
        exit();
    } else {
        $_SESSION['notif'] = "Gagal memperbarui produk.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>kasir</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <a class="navbar-brand ps-3" href="index.php">Toko Rahma</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
    </nav>

    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Navigasi</div>
                        <a class="nav-link" href="index.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>
                        <a class="nav-link" href="pelanggan.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                            Pelanggan
                        </a>
                        <a class="nav-link" href="produk.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Produk/Barang
                        </a>

                        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#stokMenu" aria-expanded="false" aria-controls="stokMenu">
                            <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                            Stok
                            <i class="fas fa-chevron-down ms-auto"></i>
                        </a>
                        <div class="collapse" id="stokMenu">
                            <a class="nav-link" href="stok_masuk.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-down"></i></div>
                                Stok Masuk
                            </a>
                            <a class="nav-link" href="stok_keluar.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-arrow-up"></i></div>
                                Stok Keluar
                            </a>
                        </div>

                        <a class="nav-link" href="pembelian.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                            Pembelian
                        </a>
                        <a class="nav-link" href="keranjang.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Keranjang
                        </a>
                        <a class="nav-link" href="user.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                            User
                         </a>
                         <a class="nav-link" href="laporan_transaksi.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-shopping-cart"></i></div>
                            Laporan Transaksi
                        </a>
                        <a class="nav-link" href="logout.php">
                            <div class="sb-nav-link-icon"><i class="fas fa-table"></i></div>
                            Logout
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>
                    <?php echo $_SESSION['user']['nama']; ?>
                </div>
            </nav>
        </div>

        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4">Ubah Produk</h1>
                    <ol class="breadcrumb mb-4">
                        <a href="produk.php" class="btn btn-danger">Kembali</a>
                        
                    </ol>

                    <!-- Menampilkan notifikasi jika ada -->
                    <?php
                    if (isset($_SESSION['notif'])) {
                        echo '<div class="alert alert-info">' . $_SESSION['notif'] . '</div>';
                        unset($_SESSION['notif']);
                    }
                    ?>

                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="id_produk" value="<?php echo $data['id_produk']; ?>">
                        <div class="mb-3">
                            <label for="nama_produk" class="form-label">Nama Produk</label>
                            <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?php echo $data['nama_produk']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga</label>
                            <input type="number" class="form-control" id="harga" name="harga" value="<?php echo $data['harga']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="harga_jual">Harga Jual</label>
                        <input type="number" name="harga_jual" class="form-control" value="<?php echo $data['harga_jual']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="number" class="form-control" id="stok" name="stok" value="<?php echo $data['stok']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="kategori" class="form-label">Kategori</label>
                            <input type="text" class="form-control" id="kategori" name="kategori" value="<?php echo $data['kategori']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="kode_barang" class="form-label">Kode Barang</label>
                            <input type="text" class="form-control" id="kode_barang" name="kode_barang" value="<?php echo $data['kode_barang']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="satuan" class="form-label">Satuan</label>
                            <input type="text" class="form-control" id="satuan" name="satuan" value="<?php echo $data['satuan']; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="gambar" class="form-label">Gambar Produk</label>
                            <input type="file" class="form-control" id="gambar" name="gambar">
                            <img src="uploads/<?php echo $data['gambar']; ?>" alt="Gambar Produk" style="width: 100px; margin-top: 10px;">
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </form>
                </div>
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
