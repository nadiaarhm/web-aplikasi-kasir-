<?php
include_once "koneksi.php";
if (isset($_GET['id'])) {
    $id_stok = $_GET['id_stok'];
    $hapus = mysqli_query($koneksi, "DELETE FROM stok_masuk WHERE id_stok = '$id_stok'");

    if ($hapus) {
        $_SESSION['notif'] = "Data berhasil dihapus!";
    } else {
        $_SESSION['notif'] = "Gagal menghapus data.";
    }
}
header('location:stok_masuk.php');
?>
