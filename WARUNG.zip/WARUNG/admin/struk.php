<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);

}
$transaksi = $_SESSION['transaksi'];

// Ambil nama pelanggan berdasarkan id_pelanggan yang ada di sesi
$id_pelanggan = $transaksi['id_pelanggan'];
$query = mysqli_query($conn, "SELECT nama_pelanggan FROM pelanggan WHERE id_pelanggan = '$id_pelanggan'");
$pelanggan = mysqli_fetch_assoc($query);
$nama_pelanggan = $pelanggan['nama_pelanggan'];


foreach ($transaksi['keranjang'] as $item) {
    $nama_produk = $item['nama_produk'];
    $jumlah = $item['jumlah'];
    $tanggal = date('Y-m-d');  // Mengambil tanggal hari ini
    $keterangan = "Stok keluar";  // Menambahkan keterangan otomatis


    // Menambahkan data ke tabel stok_keluar
    $insert_stok_keluar = "INSERT INTO stok_keluar (nama_produk, jumlah, keterangan, tanggal) 
                           VALUES ('$nama_produk', '$jumlah', '$keterangan', '$tanggal')";
    mysqli_query($conn, $insert_stok_keluar);
}


// Iterasi setiap item di keranjang untuk dimasukkan ke dalam laporan_transaksi
foreach ($transaksi['keranjang'] as $item) {
    $nama_produk = $item['nama_produk'];
    $jumlah = $item['jumlah'];
    $harga = $item['harga'];
    $total = $harga * $jumlah;
    $tanggal = date("Y-m-d");
    
    // Simpan data transaksi ke database
$query = "INSERT INTO laporan_transaksi (nama_pelanggan, nama_produk, harga, jumlah, total, tanggal) 
          VALUES ('$nama_pelanggan', '$nama_produk', '$harga', '$jumlah', '$total', NOW())";
mysqli_query($conn, $query) or die("Gagal menyimpan data transaksi: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Pembayaran</title>
    <style>
        body {
            font-family: "Courier New", Courier, monospace;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .struk {
            width: 300px;
            margin: 20px auto;
            padding: 15px;
            border: 1px dashed #000;
            font-size: 14px;
            line-height: 1.5;
            background-color: #f9f9f9;
        }
        .struk h2 {
            margin: 0;
            padding-bottom: 10px;
            font-size: 18px;
            font-weight: bold;
        }
        .struk .info {
            font-size: 12px;
            margin-bottom: 15px;
        }
        .struk table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        .struk table th, .struk table td {
            padding: 5px;
            text-align: left;
            border-bottom: 1px dotted #000;
        }
        .struk table th {
            text-align: center;
            font-size: 12px;
        }
        .struk .total {
            font-weight: bold;
            text-align: right;
            margin-top: 10px;
        }
        .struk .garis-putus {
            margin-top: 10px;
            border-top: 1px dotted #000;
            margin-bottom: 10px;
        }
        .btn-print {
            display: block;
            margin: 20px auto;
            padding: 8px 20px;
            background: #4CAF50;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
        }
        .btn-print:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="struk">
        <h2>Struk Pembayaran</h2>
        <div class="info">
            <p>Tanggal: <?= $transaksi['waktu'] ?></p>
            <p>Kasir: [Kasir Rahma]</p>
            <p>Nama Pelanggan: <?= $nama_pelanggan ?></p> <!-- Nama pelanggan ditampilkan disini -->
        </div>

        <div class="garis-putus"></div>

        <table>
            <tr>
                <th>Nama Produk</th>
                <th>Jumlah</th>
                <th>Total</th>
            </tr>
            <?php foreach ($transaksi['keranjang'] as $item): ?>
            <tr>
                <td><?= $item['nama_produk'] ?></td>
                <td><?= $item['jumlah'] ?></td>
                <td>Rp <?= number_format($item['harga'] * $item['jumlah'], 0, ',', '.') ?></td>
            </tr>
            <?php endforeach; ?>
        </table>

        <div class="garis-putus"></div>

        <div class="total">
            <p>Total Harga: Rp <?= number_format($transaksi['total_harga'], 0, ',', '.') ?></p>
            <p>Uang Dibayar: Rp <?= number_format($transaksi['uang_dibayar'], 0, ',', '.') ?></p>
            <p>Kembalian: Rp <?= number_format($transaksi['kembalian'], 0, ',', '.') ?></p>
        </div>

        <div class="garis-putus"></div>

        <p>Terima kasih atas kunjungan Anda!</p>

        <a href="#" class="btn-print" onclick="window.print()">Cetak Struk</a>
        <a href="keranjang.php" class="btn btn-danger">Kembali</a>
    </div>
</body>
</html>
