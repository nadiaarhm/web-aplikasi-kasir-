<?php
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama_pelanggan'];
    $alamat = $_POST['alamat'];
    $no_telepon = $_POST['no_telepon'];

    $sql = "INSERT INTO pelanggan (nama_pelanggan, alamat, no_telepon) 
            VALUES ('$nama', '$alamat', '$no_telepon')";
    if ($conn->query($sql)) {
        header("Location: ?page=pelanggan");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pelanggan</title>
</head>
<body>
    <h1>Tambah Pelanggan</h1>
    <form action="" method="post">
        <label>Nama Pelanggan:</label>
        <input type="text" name="nama_pelanggan" required><br>
        <label>Alamat:</label>
        <textarea name="alamat" required></textarea><br>
        <label>No Telepon:</label>
        <input type="text" name="no_telepon" required><br>
        <button type="submit">Simpan</button>
    </form>
</body>
</html>
