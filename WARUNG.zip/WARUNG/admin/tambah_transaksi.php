<?php
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data pelanggan
$pelanggan = $conn->query("SELECT * FROM pelanggan");

// Ambil data produk
$produk = $conn->query("SELECT * FROM produk");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_pelanggan = $_POST['id_pelanggan'];
    $total_harga = 0;
    $tanggal_transaksi = date('Y-m-d H:i:s');

    // Simpan transaksi
    $sql = "INSERT INTO transaksi (id_pelanggan, tanggal_transaksi, total_harga) 
            VALUES ('$id_pelanggan', '$tanggal_transaksi', 0)";
    $conn->query($sql);
    $id_transaksi = $conn->insert_id;

    // Simpan detail transaksi
    foreach ($_POST['produk'] as $key => $id_produk) {
        $jumlah = $_POST['jumlah'][$key];
        $harga = $_POST['harga'][$key];
        $sub_total = $jumlah * $harga;
        $total_harga += $sub_total;

        $sql = "INSERT INTO detail_transaksi (id_transaksi, id_produk, jumlah, sub_total) 
                VALUES ('$id_transaksi', '$id_produk', '$jumlah', '$sub_total')";
        $conn->query($sql);
    }

    // Update total transaksi
    $conn->query("UPDATE transaksi SET total_harga = '$total_harga' WHERE id_transaksi = '$id_transaksi'");

    header("Location: ?page=transaksi");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi</title>
</head>
<body>
    <h1>Tambah Transaksi</h1>
    <form action="" method="post" id="transaksi-form">
        <label>Pilih Pelanggan:</label>
        <select name="id_pelanggan" required>
            <option value="">-- Pilih Pelanggan --</option>
            <?php while ($row = $pelanggan->fetch_assoc()) { ?>
                <option value="<?= $row['id_pelanggan'] ?>"><?= $row['nama_pelanggan'] ?></option>
            <?php } ?>
        </select><br><br>

        <table>
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Sub Total</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody id="detail-transaksi">
                <tr>
                    <td>
                        <select name="produk[]" required>
                            <option value="">-- Pilih Produk --</option>
                            <?php while ($row = $produk->fetch_assoc()) { ?>
                                <option value="<?= $row['id_produk'] ?>" data-harga="<?= $row['harga'] ?>">
                                    <?= $row['nama_produk'] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </td>
                    <td><input type="number" name="jumlah[]" required></td>
                    <td><input type="text" name="harga[]" readonly></td>
                    <td><input type="text" name="sub_total[]" readonly></td>
                    <td><button type="button" onclick="hapusBaris(this)">Hapus</button></td>
                </tr>
            </tbody>
        </table>
        <button type="button" onclick="tambahBaris()">Tambah Produk</button><br><br>

        <div>
            <label>Total Harga: </label>
            <input type="text" id="total-harga" name="total_harga" value="0" readonly><br><br>
        </div>

        <div>
            <label>Bayar: </label>
            <input type="number" id="bayar" name="bayar" required><br><br>

            <label>Kembalian: </label>
            <input type="text" id="kembalian" readonly><br><br>
        </div>

        <button type="submit" id="submit-button" disabled>Simpan Transaksi</button>
    </form>

    <script>
        function tambahBaris() {
            const row = document.querySelector('#detail-transaksi tr').cloneNode(true);
            document.querySelector('#detail-transaksi').appendChild(row);
            updateTotalHarga();
        }

        function hapusBaris(btn) {
            if (document.querySelectorAll('#detail-transaksi tr').length > 1) {
                btn.closest('tr').remove();
                updateTotalHarga();
            }
        }

        function updateTotalHarga() {
            let totalHarga = 0;
            document.querySelectorAll('#detail-transaksi tr').forEach(row => {
                const harga = row.querySelector('select[name="produk[]"]').selectedOptions[0].getAttribute('data-harga');
                const jumlah = row.querySelector('input[name="jumlah[]"]').value;
                const subTotal = harga * jumlah;
                row.querySelector('input[name="harga[]"]').value = harga;
                row.querySelector('input[name="sub_total[]"]').value = subTotal;
                totalHarga += subTotal;
            });

            document.getElementById('total-harga').value = totalHarga;
            checkBayar(totalHarga);
        }

        function checkBayar(totalHarga) {
            const bayar = document.getElementById('bayar').value;
            if (bayar >= totalHarga) {
                document.getElementById('submit-button').disabled = false;
                document.getElementById('kembalian').value = bayar - totalHarga;
            } else {
                document.getElementById('submit-button').disabled = true;
                document.getElementById('kembalian').value = 0;
            }
        }

        document.querySelector('#transaksi-form').addEventListener('input', function() {
            updateTotalHarga();
            const totalHarga = parseFloat(document.getElementById('total-harga').value);
            checkBayar(totalHarga);
        });
    </script>
</body>
</html>
