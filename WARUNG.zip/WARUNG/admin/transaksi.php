<?php
$conn = new mysqli('localhost', 'root', '', 'db_kasir');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data transaksi beserta nama pelanggan
$sql = "
    SELECT t.id_transaksi, t.tanggal_transaksi, t.total_harga, p.nama_pelanggan
    FROM transaksi t
    JOIN pelanggan p ON t.id_pelanggan = p.id_pelanggan
    ORDER BY t.id_transaksi DESC
";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi</title>
</head>
<body>
    <h1>Daftar Transaksi</h1>
    <a href="?page=tambah_transaksi">Tambah Transaksi</a>
    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Transaksi</th>
                <th>Nama Pelanggan</th>
                <th>Total Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                $no = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . $no++ . "</td>
                            <td>" . $row['tanggal_transaksi'] . "</td>
                            <td>" . $row['nama_pelanggan'] . "</td>
                            <td>Rp " . number_format($row['total_harga'], 0, ',', '.') . "</td>
                            <td>
                                <a href='?page=detail_transaksi&id=" . $row['id_transaksi'] . "'>Lihat Detail</a>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>Tidak ada data transaksi.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
