-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2025 at 09:16 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kasir`
--

-- --------------------------------------------------------

--
-- Table structure for table `detailpenjualan`
--

CREATE TABLE IF NOT EXISTS `detailpenjualan` (
  `id_detail` int(11) NOT NULL,
  `id_penjualan` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah_produk` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `laporan_transaksi`
--

CREATE TABLE IF NOT EXISTS `laporan_transaksi` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(255) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` decimal(10,2) NOT NULL,
  `tanggal` date NOT NULL,
  `total` decimal(10,0) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `laporan_transaksi`
--

INSERT INTO `laporan_transaksi` (`id_pelanggan`, `nama_pelanggan`, `nama_produk`, `jumlah`, `harga`, `tanggal`, `total`) VALUES
(1, 'eka purwati', 'Roma Sari Gandum Sanwich Coklat 12 sachet', 1, '22500.00', '2025-01-23', '22500'),
(2, 'stepani lumbanraja', 'lasegar kaleng jeruk', 2, '5000.00', '2025-01-23', '10000'),
(3, 'jihan marsa syahfira', 'bantan sarden kecil', 1, '9000.00', '2025-01-23', '9000'),
(4, 'noni astara', 'deterjen daia 850gr', 1, '19500.00', '2025-01-23', '19500'),
(5, 'stepani lumbanraja', 'indomie rasa rawon mercon pedas', 2, '2500.00', '2025-01-23', '5000'),
(6, 'aaaaaaaaaaaaaaaaaaaaaaa', 'sabun mandi lifebuoy', 1, '1500.00', '2025-01-23', '1500'),
(7, 'jihan marsa syahfira', 'indomie rasa soto mie', 1, '2500.00', '2025-02-04', '2500');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(30) NOT NULL,
  `email` varchar(10) NOT NULL,
  `alamat` text NOT NULL,
  `jenis_kelamin` enum('Laki-Laki','Perempuan') NOT NULL,
  `no_telepon` varchar(6) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `email`, `alamat`, `jenis_kelamin`, `no_telepon`) VALUES
(3, 'jihan marsa syahfira', 'jinay@gmai', 'sumber mulya', 'Perempuan', '081573'),
(4, 'stepani lumbanraja', 'pani12@gma', 'tayas', 'Perempuan', '087790'),
(5, 'devi safira', 'devi@gmail', 'priss', 'Perempuan', '081573'),
(6, 'eka purwati', 'eka20@gmai', 'talang bukit ', 'Perempuan', '081573'),
(7, 'noni astara', 'noni10@gma', 'sumber mulya', 'Perempuan', '083390');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE IF NOT EXISTS `pembelian` (
  `id_pembelian` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `tanggal` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `id_user`, `id_produk`, `jumlah`, `total_harga`, `tanggal`) VALUES
(1, 0, 8, 19, 228000, '2025-01-13 08:04:18'),
(2, 0, 10, 6, 30000, '2025-01-13 08:04:18'),
(3, 0, 16, 4, 24000, '2025-01-13 08:04:18'),
(4, 0, 3, 20, 60000, '2025-01-13 08:04:59'),
(5, 0, 3, 5, 15000, '2025-01-13 08:16:41'),
(6, 0, 8, 30, 360000, '2025-01-13 08:17:15'),
(7, 0, 11, 15, 240000, '2025-01-13 08:25:36'),
(8, 0, 6, 7, 63000, '2025-01-13 08:50:28'),
(9, 0, 8, 35, 420000, '2025-01-14 02:15:00'),
(10, 0, 1, 5, 15000, '2025-01-14 14:58:07'),
(11, 0, 2, 2, 24000, '2025-01-14 14:58:07'),
(12, 0, 6, 10, 54000, '2025-01-14 14:58:07'),
(13, 0, 3, 4, 48000, '2025-01-14 14:58:07'),
(14, 0, 7, 50, 1000000, '2025-01-16 03:52:08'),
(15, 0, 1, 0, 2500, '2025-02-04 08:14:41'),
(16, 0, 1, 1, 2500, '2025-02-04 08:16:26'),
(17, 0, 1, 1, 2500, '2025-02-04 08:17:06'),
(18, 0, 1, 0, 0, '2025-02-04 08:22:08'),
(19, 0, 1, 0, 0, '2025-02-04 08:22:44'),
(20, 0, 1, 0, 0, '2025-02-04 08:24:32');

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE IF NOT EXISTS `penjualan` (
  `id_penjualan` int(11) NOT NULL,
  `tanggal_penjualan` date NOT NULL,
  `total_harga` decimal(10,2) NOT NULL,
  `id_pelanggan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `tanggal_penjualan`, `total_harga`, `id_pelanggan`) VALUES
(0, '2025-01-10', '0.00', 5),
(5, '2025-01-10', '0.00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE IF NOT EXISTS `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `harga` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `satuan` varchar(11) NOT NULL,
  `kategori` varchar(50) DEFAULT NULL,
  `kode_barang` varchar(50) DEFAULT NULL,
  `gambar` varchar(25) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `harga`, `harga_jual`, `stok`, `satuan`, `kategori`, `kode_barang`, `gambar`) VALUES
(1, 'indomie rasa soto mie', 2500, 4000, 11, 'pcs', 'Makanan', 'A01', 'mie soto.jpg'),
(2, 'indomie rasa rawon mercon pedas', 2500, 4000, 13, 'pcs', 'Makanan', 'A02', 'mie mercon.jpg'),
(3, 'indomie rasa ayam bawang', 2500, 4000, 20, 'pcs', 'Makanan', 'A03', 'mie ayam.jpg'),
(4, 'bantan sarden kecil', 9000, 11000, 14, 'ml', 'Makanan', 'A04', 'sarden kecil.jpg'),
(5, 'Aqua Botol', 3000, 4000, 27, 'ml', 'Minuman', 'B01', 'aqua.jpg'),
(6, 'lasegar kaleng jeruk', 5000, 7500, 8, 'ml', 'Minuman', 'B02', 'lasegar.png'),
(7, 'sabun mandi lifebuoy', 1500, 2000, 23, 'gram', 'Sabun', 'C01', 'liveboy.jpg'),
(8, 'deterjen daia 850gr', 19500, 22000, 4, 'gram', 'Sabun', 'C02', 'dtrjn.jpg'),
(9, 'Roma Sari Gandum Sanwich Coklat 12 sachet', 22500, 25000, 26, 'gr', 'Makanan', 'A05', 'roma.jpg'),
(11, 'masako penyedap rasa sapi', 300, 500, 48, 'pcs', 'Penyedap Makanan', 'D01', 'masako s.jpg'),
(12, 'Energen sachet', 1500, 2000, 40, 'pcs', 'Minuman', 'A06', 'energen.jpg'),
(13, 'pocari sweat 500ml', 7500, 8000, 14, 'ml', 'Minuman', 'B04', 'pocari.png'),
(14, 'Indomilk susu kental manis', 10000, 12000, 10, 'Kaleng', 'Minuman', 'B06', 'susu.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `stok_keluar`
--

CREATE TABLE IF NOT EXISTS `stok_keluar` (
  `id_stok` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `nama_produk` varchar(35) NOT NULL,
  `jumlah` varchar(10) NOT NULL,
  `keterangan` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stok_keluar`
--

INSERT INTO `stok_keluar` (`id_stok`, `tanggal`, `nama_produk`, `jumlah`, `keterangan`) VALUES
(1, '2025-01-22', 'Roma Sari Gandum Sanwich Coklat 12 ', '3', 'Stok keluar'),
(2, '2025-01-22', 'Aqua Botol', '1', 'Stok keluar'),
(3, '2025-01-22', 'masako penyedap rasa sapi', '2', 'Stok keluar'),
(4, '2025-01-22', 'indomie rasa rawon mercon pedas', '4', 'Stok keluar'),
(5, '2025-01-22', 'indomie rasa soto mie', '5', 'Stok keluar'),
(6, '2025-01-23', 'sabun mandi lifebuoy', '3', 'Stok keluar'),
(7, '2025-01-23', 'deterjen daia 850gr', '2', 'Stok keluar'),
(8, '2025-01-23', 'Roma Sari Gandum Sanwich Coklat 12 ', '1', 'Stok keluar'),
(9, '2025-01-23', 'lasegar kaleng jeruk', '2', 'Stok keluar'),
(10, '2025-01-23', 'bantan sarden kecil', '1', 'Stok keluar'),
(11, '2025-01-23', 'deterjen daia 850gr', '1', 'Stok keluar'),
(12, '2025-01-23', 'indomie rasa rawon mercon pedas', '2', 'Stok keluar'),
(13, '2025-01-23', 'sabun mandi lifebuoy', '1', 'Stok keluar'),
(14, '2025-02-04', 'indomie rasa soto mie', '1', 'Stok keluar');

-- --------------------------------------------------------

--
-- Table structure for table `stok_masuk`
--

CREATE TABLE IF NOT EXISTS `stok_masuk` (
  `id_stok` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `kode_barang` varchar(20) NOT NULL,
  `stok` varchar(10) NOT NULL,
  `keterangan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stok_masuk`
--

INSERT INTO `stok_masuk` (`id_stok`, `tanggal`, `kode_barang`, `stok`, `keterangan`) VALUES
(0, '2025-01-23', 'B04', '15', 'Stok masuk'),
(0, '2025-01-23', 'C06', '10', 'Stok masuk');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(25) NOT NULL,
  `role` enum('admin','petugas') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`, `role`) VALUES
(12, 'petugas', '12', 'petugas'),
(16, 'petugas', '123', 'petugas'),
(18, 'admin', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `detailpenjualan`
--
ALTER TABLE `detailpenjualan`
  ADD PRIMARY KEY (`id_detail`);

--
-- Indexes for table `laporan_transaksi`
--
ALTER TABLE `laporan_transaksi`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `stok_keluar`
--
ALTER TABLE `stok_keluar`
  ADD PRIMARY KEY (`id_stok`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `laporan_transaksi`
--
ALTER TABLE `laporan_transaksi`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `stok_keluar`
--
ALTER TABLE `stok_keluar`
  MODIFY `id_stok` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
