<?php
session_start();
include('koneksi.php'); // Pastikan Anda sudah menyiapkan koneksi ke database

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mengambil data pengguna dari database
    $query = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        
        // Menyimpan informasi pengguna ke dalam session
        $_SESSION['username'] = $row['username'];
        $_SESSION['role'] = $row['role'];

        // Redirect berdasarkan peran
        if ($row['role'] == 'admin') {
            header('Location: admin/index.php');
        } else if ($row['role'] == 'petugas') {
            header('Location: petugas/index.php');
        }
    } else {
        $error = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Mengatur tampilan halaman */
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color:rgb(55, 40, 99);
        }

        /* Kontainer untuk form login */
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            width: 100%;
        }

        /* Kotak login */
        .login-box {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
        }

        /* Judul */
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        /* Label dan input */
        label {
            margin-top: 10px;
            display: block;
            padding-left: 10px;  /* Menambahkan padding kiri */
            padding-right: 10px; /* Menambahkan padding kanan */
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box; /* Memastikan padding tidak mengganggu lebar input */
            font-size: 14px;
        }

        /* Placeholder style */
        input::placeholder {
            color: #bbb;  /* Warna teks placeholder */
           /* Menambahkan gaya miring pada teks placeholder */
        }

        /* Tombol login */
        button {
            width: 100%;
            padding: 10px;
            background-color:rgb(27, 24, 56);
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            box-sizing: border-box; /* Menjaga ukuran tombol agar pas */
        }

        button:hover {
            background-color:rgb(125, 98, 189);
        }

        /* Pesan error */
        .error {
            color: red;
            font-size: 14px;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <div class="login-box">
            <h2>Login</h2>
            <form method="POST" action="login.php">
                <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
                
                <input type="text" id="username" name="username" placeholder="Username" required>

                <label for="password"></label>
                <input type="password" id="password" name="password" placeholder="Password" required>

                <button type="submit" name="login">Login</button>
            </form>
        </div>
    </div>

</body>
</html>
